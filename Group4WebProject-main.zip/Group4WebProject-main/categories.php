<html>
<head>
<title> Seminar Coding</title> 

</head>
<body>
<h1>Here Are The Categories of Programming Languages</h1>
<p><strong>Click the name to know about it</strong></p>
<p><a href= "categories/paitan.php">Pyton</p>
<p><a href= "categories/cplus.php">C++</p>
<p><a href= "categories/java.php">Java</p>
<p><a href= "categories/PHP.php">PHP</p>

</body>
</html>