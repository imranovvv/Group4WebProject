<html>
<head>
	<title>PHP</title>
	
</head>
<body>

<h3>Purpose:</h3>
<p>Described as specially suited for web development on their official website,</p> 
<p>the Hypertext Preprocessor language, popularly known as PHP, came into existence in 1994.</p> 
<p>It is an open-source language, free for downloading, and can be used on any platform,</p>
<p>from Linux to Windows.</p>
<h3>Popularity:</h3>
<p>A survey by the W3Techs shows that PHP is used by 77.3 percent of all the websites whose server-side programming language is known.</p>
<h3>Pros and Cons:</h3>
<p>Its open-source nature is not as secure as other programming languages and unsuitable for coding larger content-based applications.</p>


</body>
</head>
</html>