<html>
<head>
	<title>C++</title>
	
</head>
<body>
<h3>Purpose:</h3>
<p> The two programming languages are used interchangeably in daily conversation, with C’s creation in 1972 and C++ in 1985.</p>
<p>Both are general-purpose programming languages, with their code used to implement operating systems such as Oracle and Intel.</p>
<h3>Popularity:</h3>
<p>C++ is known as the ‘superset’ of C, with slightly more comprehensive grammar</p>
<h3>Pros and Cons:</h3>
<p>The languages are simple, compiled, and have comprehensive library support. However, both languages have similar issues in terms of excessive memory usage.</p>

</body>
</head>
</html>