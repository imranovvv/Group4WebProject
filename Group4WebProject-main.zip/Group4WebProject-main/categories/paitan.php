<html>
<head>
	<title>Python</title>
	
</head>
<body>
<h3>Purpose:</h3>
<p> Python is a general-purpose dynamic programming language created in 1991.  </p>
<h3>Popularity:</h3>
<p>It’s one of the most popular coding languages today and is used for server-side web and system development.</p>
<h3>Pros and Cons:</h3>
<p>The language has a simple syntax and can work on multiple platforms, making it far easier to learn and execute.</p> 
<p>It is one of the first programming languages that most coders learn. However, it has a lower execution speed compared to other languages. .</p>
</body>
</head>
</html>
