<html>
<head>
	<title>Java</title>
	
</head>
<body>
<h3>Purpose:</h3>
<p> Created in 1995, the language is general purpose and object-oriented,  as it does not use features </p> 
<p>allowing coders to develop everything from web and mobile applications to embedded servers. </p> 
<p>The language can be used on any platform and is one of the simplest languages to learn,</p>
<p>such as operator overloading and multiple inheritances. These factors make Java a far more user-friendly programming language. </p>
<h3>Popularity:</h3>
<p>Java is one of the most popular programming languages worldwide.</p>
<h3>Pros and Cons:</h3>
<p>Unlike most other languages, Java can be written on one device and run across various devices, making it portable.</p> 
<p>However, unfortunately, the language does not provide a backup facility and must be stored on the device’s storage.</p>

</body>
</head>
</html>